﻿using UdonSharp;
using UnityEditor;
using UnityEngine;
using UnityEngine.UI;
using VRC.SDK3.Data;
using RehubSystem.EditorShared;

namespace RehubSystem
{
    [UdonBehaviourSyncMode(BehaviourSyncMode.None)]
    public class SystemSettingsModule : UdonSharpBehaviour
    {
        [SerializeField] private I18nManager _systemI18nManager;
        [SerializeField] private RadioButtonHelper _languageSelector;
        [SerializeField] private RadioButtonHelper _qmDesktopKeybindSelector; // Desktop用
        [SerializeField] private RadioButtonHelper _qmKeybindSelector; // VR用
        [SerializeField] private RadioButtonHelper _qmDominantHandSelector;
        [SerializeField] private ApplyI18n _qmKeybindNoticeText;
        [SerializeField] private QuickMenuManager _quickMenuManager;
        [SerializeField] private CloudSyncManager _cloudSyncManager;
        [SerializeField] private Text _quickMenuSizeText;
        [SerializeField] private Text _quickMenuPositionXText;
        [SerializeField] private Text _quickMenuPositionYText;
        [SerializeField] private Text _quickMenuPositionZText;

        private float _quickMenuSize = 1f;
        private float _vrScreenPositionX = 0.0f;
        private float _vrScreenPositionY = -0.15f;
        private float _vrScreenPositionZ = 0.15f;

        private void Start()
        {
            if (_systemI18nManager == null || _quickMenuManager == null || _quickMenuSizeText == null)
            {
                Debug.LogWarning("SystemSettingsModule: Some optional components are missing.");
            }

            ChangeQuickMenuSize(true);
            // ChangeQuickMenuPosition();

            if (_cloudSyncManager != null)
            {
                _cloudSyncManager.OnLoad(this, nameof(OnCloudSyncLoaded));
            }
        }

        public void OnCloudSyncLoaded()
        {
            var data = _cloudSyncManager.SyncData;
            if (data == null) return;

            if (data.ContainsKey("qmsize") && data.TryGetValue("qmsize", out var size))
            {
                switch (size.TokenType)
                {
                    case TokenType.Double:
                        _quickMenuSize = (float)size.Double;
                        break;
                    case TokenType.Float:
                        _quickMenuSize = size.Float;
                        break;
                    case TokenType.Int:
                        _quickMenuSize = size.Int;
                        break;
                }
                ChangeQuickMenuSize(true);
            }

            if (_qmKeybindSelector != null && data.ContainsKey("qmkeybind") && data.TryGetValue("qmkeybind", out var keybind))
            {
                _qmKeybindSelector.SetValue(keybind.String);
                UpdateQMKeyBind(keybind.String);
            }

            if (_qmDesktopKeybindSelector != null && data.ContainsKey("qmdesktopkeybind") && data.TryGetValue("qmdesktopkeybind", out var desktopKeybind))
            {
                _qmDesktopKeybindSelector.SetValue(desktopKeybind.String);
                UpdateDesktopQMKeyBind(desktopKeybind.String);
            }

            if (_qmDominantHandSelector != null && data.ContainsKey("qmdominanthand") && data.TryGetValue("qmdominanthand", out var dominantHand))
            {
                _qmDominantHandSelector.SetValue(dominantHand.String);
                UpdateQMDominantHand(dominantHand.String);
            }

            if (_languageSelector != null && data.ContainsKey("lang") && data.TryGetValue("lang", out var lang))
            {
                _languageSelector.SetValue(lang.String);
                _systemI18nManager.SetLanguage(lang.String);
            }
        }

        public void UpdateLanguage()
        {
            if (_systemI18nManager == null) return;
            if (_languageSelector == null) return;

            var language = _languageSelector.Value;
            _systemI18nManager.SetLanguage(language);
            if (_cloudSyncManager != null) _cloudSyncManager.Save("lang", language);
        }

        public void UpdateDesktopQMKeyBind()
        {
            if (_qmDesktopKeybindSelector == null) return;
            UpdateDesktopQMKeyBind(_qmDesktopKeybindSelector.Value);
            if (_cloudSyncManager != null) _cloudSyncManager.Save("qmdesktopkeybind", _qmDesktopKeybindSelector.Value);
        }

        public void UpdateDesktopQMKeyBind(string value)
        {
            switch (value)
            {
                case "tab":
                    _quickMenuManager.SetDesktopOpenMethod(DesktopQuickMenuOpenMethod.Tab);
                    break;
                case "shiftTab":
                    _quickMenuManager.SetDesktopOpenMethod(DesktopQuickMenuOpenMethod.ShiftTab);
                    break;
                default:
                    _quickMenuManager.ResetDesktopOpenMethod();
                    break;
            }
        }

        // VR用 後方互換性のためにメソッド名は変更なし
        public void UpdateQMKeyBind()
        {
            if (_quickMenuManager == null) return;
            if (_qmKeybindSelector == null) return;
            UpdateQMKeyBind(_qmKeybindSelector.Value);
            if (_cloudSyncManager != null) _cloudSyncManager.Save("qmkeybind", _qmKeybindSelector.Value);
        }

        // VR用 後方互換性のためにメソッド名は変更なし
        public void UpdateQMKeyBind(string value)
        {
            switch (value)
            {
                case "stick":
                    _quickMenuManager.SetVrOpenMethod(VRQuickMenuOpenMethod.Stick);
                    break;
                case "trigger":
                    _quickMenuManager.SetVrOpenMethod(VRQuickMenuOpenMethod.Trigger);
                    break;
                case "triggerCombo":
                    _quickMenuManager.SetVrOpenMethod(VRQuickMenuOpenMethod.TriggerCombo);
                    break;
                default:
                    _quickMenuManager.ResetVrOpenMethod();
                    break;
            }
        }

        public void UpdateQMDominantHand()
        {
            if (_quickMenuManager == null) return;
            if (_qmDominantHandSelector == null) return;
            UpdateQMDominantHand(_qmDominantHandSelector.Value);
            if (_cloudSyncManager != null) _cloudSyncManager.Save("qmdominanthand", _qmDominantHandSelector.Value);

            var dominantHand = _quickMenuManager.DominantHand == VRQuickMenuDominantHand.Left ? "left" : "right";
            var nonDominantHand = _quickMenuManager.DominantHand == VRQuickMenuDominantHand.Left ? "right" : "left";

            var argValues = new string[4];
            argValues[0] = dominantHand;
            argValues[1] = dominantHand;
            argValues[2] = nonDominantHand;
            argValues[3] = dominantHand;
            if (_qmKeybindNoticeText != null)
            {
                _qmKeybindNoticeText.argValues = argValues;
            }
        }

        public void UpdateQMDominantHand(string value)
        {
            switch (value)
            {
                case "left":
                    _quickMenuManager.SetDominantHand(VRQuickMenuDominantHand.Left);
                    break;
                case "right":
                    _quickMenuManager.SetDominantHand(VRQuickMenuDominantHand.Right);
                    break;
                default:
                    _quickMenuManager.ResetDominantHand();
                    break;
            }
        }

        public void QMSizeUp()
        {
            _quickMenuSize = Mathf.Clamp(_quickMenuSize + 0.1f, 0.5f, 1.5f);
            ChangeQuickMenuSize();
        }

        public void QMSizeDown()
        {
            _quickMenuSize = Mathf.Clamp(_quickMenuSize - 0.1f, 0.5f, 1.5f);
            ChangeQuickMenuSize();
        }

        public void QMPositionXUp()
        {
            _vrScreenPositionX += 0.01f;
            ChangeQuickMenuPosition();
        }

        public void QMPositionXDown()
        {
            _vrScreenPositionX -= 0.01f;
            ChangeQuickMenuPosition();
        }

        public void QMPositionYUp()
        {
            _vrScreenPositionY += 0.01f;
            ChangeQuickMenuPosition();
        }

        public void QMPositionYDown()
        {
            _vrScreenPositionY -= 0.01f;
            ChangeQuickMenuPosition();
        }

        public void QMPositionZUp()
        {
            _vrScreenPositionZ += 0.01f;
            ChangeQuickMenuPosition();
        }

        public void QMPositionZDown()
        {
            _vrScreenPositionZ -= 0.01f;
            ChangeQuickMenuPosition();
        }

        public void ChangeQuickMenuSize(bool skipSave = false)
        {
            if (_quickMenuManager == null) return;
            if (_quickMenuSizeText == null) return;

            _quickMenuManager.SetMenuSize(_quickMenuSize);
            _quickMenuSizeText.text = _quickMenuSize.ToString("P0");
            if (!skipSave && _cloudSyncManager != null) _cloudSyncManager.Save("qmsize", _quickMenuSize);
        }

        public void ChangeQuickMenuPosition()
        {
            if (_quickMenuManager == null) return;
            if (_quickMenuPositionXText == null || _quickMenuPositionYText == null || _quickMenuPositionZText == null) return;

            _quickMenuManager.SetScreenPosition(new Vector3(_vrScreenPositionX, _vrScreenPositionY, _vrScreenPositionZ));
            _quickMenuPositionXText.text = _vrScreenPositionX.ToString("N2");
            _quickMenuPositionYText.text = _vrScreenPositionY.ToString("N2");
            _quickMenuPositionZText.text = _vrScreenPositionZ.ToString("N2");
        }
    }

#if !COMPILER_UDONSHARP && UNITY_EDITOR
    [CustomEditor(typeof(SystemSettingsModule))]
    public class SystemSettingsModuleInspector : ModuleInspector
    {
        protected override string I18nUUID => "a1e9f9d4be7f50b4280969b169245980";
        protected override string[] ObjectProperties => new string[] {
            "_systemI18nManager",
            "_languageSelector",
            "_qmDesktopKeybindSelector",
            "_qmKeybindSelector",
            "_qmDominantHandSelector",
            "_qmKeybindNoticeText",
            "_quickMenuManager",
            "_cloudSyncManager",
            "_quickMenuSizeText",
            "_quickMenuPositionXText",
            "_quickMenuPositionYText",
            "_quickMenuPositionZText"
        };

        protected override void DrawModuleInspector()
        {
            EditorGUILayout.HelpBox(_i18n.GetTranslation("description"), MessageType.Warning);
        }
    }
#endif
}
